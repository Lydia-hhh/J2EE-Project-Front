<template>
<VDistPicker></VDistPicker>
</template>

<script>
import VDistPicker from 'v-distpicker'
export default {
  name: "Test",
  components:{
    VDistPicker
  }
}
</script>

<style scoped>

</style>