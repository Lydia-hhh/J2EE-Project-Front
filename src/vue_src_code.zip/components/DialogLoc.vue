<template>

</template>

<script>
export default {
  name: "DialogLoc"
}
</script>

<style scoped>

</style>